package org.example;

public class Consumer {
}
