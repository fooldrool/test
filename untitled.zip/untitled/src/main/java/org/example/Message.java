package org.example;

public class Message {
    String messageBody;
    int messageId;

    public Message(String messageBody,String publisherName, int messageId) {
        this.messageBody = messageBody;
        this.messageId = messageId;
        this.publisherName = publisherName;
    }

    String publisherName;



}
