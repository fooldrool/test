package org.example;

import java.util.*;

public class MessageQueue {

    Map<String, List<Message>> topicMessageList;
    Map<String, List<ConsumerTopic>> consumerTopicMap;

    public int createTopic(String topicName){
        if(topicMessageList.containsKey(topicName))
            return 0;
        topicMessageList.put(topicName, new ArrayList<>());
        return 1;
    }

    public int subscribe(String topicName, String consumerName) {
        if(consumerTopicMap.containsKey(topicName)) {
            ConsumerTopic consumerTopic = new ConsumerTopic();
            consumerTopic.topicName = topicName;
            consumerTopic.consumedIdx = 0;
            consumerTopicMap.get(topicName).add(consumerTopic);
        }
        return 0;
    }
    public int produce(String topicName, Message message) {
        if(topicMessageList.containsKey(topicName))
            topicMessageList.get(topicName).add(message);
        return 1;
    }

    public List<Message> consume(String consumerName, String topicName, int offset, boolean isReplay) {
         List<Message> messages = new ArrayList<>();
         int idx = validateIfConsumerIsSubscribedToTopic(consumerName);
         //check if offset is greater than or equal to the current offset maintained in list message queue.
        List<Message> msgs = topicMessageList.get(topicName);
         messages = topicMessageList.get(topicName).subList(offset, msgs.subList(offset, msgs.size()-1));
         return messages;
    }

    private int validateIfConsumerIsSubscribedToTopic(String consumerName) {
        return 0;
    }
}
