package org.example;

public class Publisher {

    MessageQueue messageQueue;

    public Publisher(String topicName) {
        if(messageQueue == null) {
            this.messageQueue = new MessageQueue();
        }
        messageQueue.createTopic(topicName);
    }

    public int publish(String topic, Message message) {
        messageQueue.produce(topic, message);

        return 1;
    }
}
