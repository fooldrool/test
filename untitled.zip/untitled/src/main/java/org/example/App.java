package org.example;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        MessageQueue messageQueue = new MessageQueue();
        Publisher publisher = new Publisher("TestTopic");
        Consumers consumers = new Consumers(messageQueue, "testConsumer");
        Message msg = new Message("test body", "TestPub", 0);

        publisher.publish("TestTopic", msg);

        consumers.consume("testConsumer","TestTopic", 1, false);
        System.out.println( "Hello World!" );
    }

}
