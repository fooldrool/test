package org.example;

public class ConsumerTopic {

    String consumerName;
    String topicName;
    int consumedIdx;

}
