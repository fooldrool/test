package org.example;

public class Consumers {

    MessageQueue messageQueue;
    String consumerName;
    public Consumers (MessageQueue messageQueue, String consumerName) {
        messageQueue = new MessageQueue();
        this.consumerName = consumerName;
    }

    public void consume(String consumerName, String topicName, int offset, boolean isReplay) {
        messageQueue.consume(consumerName, topicName, offset, isReplay);
    }


}
